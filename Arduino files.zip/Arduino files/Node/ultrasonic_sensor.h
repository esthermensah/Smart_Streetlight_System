

void ultraSonic() {
  // Clears the trigPin
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  // Sets the trigPin on HIGH state for 10 micro seconds
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  // Reads the echoPin, returns the sound wave travel time in microseconds
  duration = pulseIn(echoPin, HIGH);
  // Calculating the distance
  distanceRec = (duration * 0.034 / 2);
  // Prints the distance on the Serial Monitor

String  ultraString2 = "AT+SEND=1,6,U,"  + String(distanceRec);
Serial.println(ultraString2);
  delay(3000);
   if (distanceRec<20) {
    brightness_on_light_intensity();
}

}
