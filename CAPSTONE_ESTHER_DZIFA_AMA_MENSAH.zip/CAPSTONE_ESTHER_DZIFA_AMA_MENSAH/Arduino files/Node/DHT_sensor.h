
void dhtFunc(){
  String  tempString;
  String  humString;
  int count=0; 
// Reading temperature or humidity takes about 250 milliseconds!
  // Sensor readings may also be up to 2 seconds 'old' (its a very slow sensor)
  float h = dht.readHumidity();
  // Read temperature as Celsius (the default)
  float t = dht.readTemperature();
  // Check if any reads failed and exit early (to try again).
  if (isnan(h) || isnan(t)) {
     tempString = "0";
     humString ="0";
    Serial.println("Failed to read from DHT sensor!");
   // return;
  }  
while(count<5){
    humidity += dht.readHumidity();
    temperature += dht.readTemperature();    
    count++;     
   }   
   humidity = humidity/count;
   temperature = temperature/count;  
   
  humString = "AT+SEND=1,15,H," + String(humidity);
  //Serial.println(String(humidity));
  Serial.println(humString);
  delay(3000);  
   tempString = "AT+SEND=1,15,T,"  + String(temperature);  
  Serial.println(tempString);
  
  }






 






    /*
void PIRmotion(){
 val = digitalRead(inputPin);  // read input value
  if (val == HIGH) {            // check if the input is HIGH
    digitalWrite(2, HIGH);  // turn LED ON
    if (pirState == LOW) {
      // we have just turned on
      Serial.println("Motion detected!");
      // We only want to print on the output change, not state
      pirState = HIGH;
    }
  } else {
 
    if (pirState == HIGH){
      // we have just turned of
      Serial.println("Motion ended!");
      // We only want to print on the output change, not state
      pirState = LOW;

    }
  }
}
*/
