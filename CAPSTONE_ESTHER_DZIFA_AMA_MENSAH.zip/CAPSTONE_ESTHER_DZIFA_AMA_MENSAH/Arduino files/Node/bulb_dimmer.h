
/*
 * This sketch calculates the energy consumption based on the formula E = P*t/ Kwh
 * the value used by the bulb in transmitted to the gateway
 * 
 */
String weatherCondition;
String  bulbCondition; 
  void brightness_on_light_intensity(){ 
    // Dimming based on the weather  
    envLight= analogRead(ldr1);  
    lampBrightness= analogRead(ldr2);
    envBrightnessLevel = map(envLight, 1, 400, 1 , 3); // analogRead(analog_pin), min_analog, max_analog, 100%, 0%);    
    if (envLight <= 200) { 
       //Here the weather is dark 
      // The bulb would be on
       digitalWrite(indicator2, HIGH);    
       weatherCondition = "Dark";     
     
      switch(envBrightnessLevel){
        case 1: 
        dimmer.setPower(50); // brightest     
        Serial.println("AT+SEND=1,10,P,5.5") ;  
        bulbCondition = "AT+SEND=1,10,L,ON";
        delay(2000);
        Serial.println(bulbCondition);        
        break;   
        case 2: 
        dimmer.setPower(40); // half power  
        Serial.println("AT+SEND=1,10,P,2.75");
        bulbCondition = "AT+SEND=1,10,L,DIM";
        delay(2000);
        Serial.println(bulbCondition);
        break;
        case 4: 
        dimmer.setPower(10); // no power    
        Serial.println("AT+SEND=1,3,P,0"); 
        bulbCondition = "AT+SEND=1,10,L,OFF";
        delay(2000);
        Serial.println(bulbCondition);
        break;
        }
      } else{
          digitalWrite(indicator2, LOW); 
          weatherCondition = "bright"; 
          dimmer.setPower(10); // no power    
        Serial.println("AT+SEND=1,3,P,0"); 
        bulbCondition = "AT+SEND=1,10,L,OFF";
        delay(2000);
        Serial.println(bulbCondition);  
        }
      String  stateOfEnvironment = "AT+SEND=1,10,E,"  + weatherCondition;
      Serial.println(stateOfEnvironment);

}
