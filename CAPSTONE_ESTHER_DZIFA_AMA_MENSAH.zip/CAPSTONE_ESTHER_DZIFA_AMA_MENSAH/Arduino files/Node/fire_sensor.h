 void fires(){  
    // read the sensor on analog A0:
 int sensorReading = analogRead(A0);
  // map the sensor range (four options):
  // ex: 'long int map(long int, long int, long int, long int, long int)'
  int range = map(sensorReading, sensorMin, sensorMax, 0, 3);
  String fire ="";
  // range value:
  switch (range) {
  case 0:    // A fire closer than 1.5 feet away.
  digitalWrite(indicator1, HIGH);    
    fire =("3");
    break;
  case 1:    // A fire between 1-3 feet away.
    fire =("2");
    break;
  case 2:    // No fire detected.
    fire =("1");
    break;    
  }
  sendingString +=  String(fire);
  //Serial.println(fire);
 // delay(1);  // delay between reads  

   String  fireString = "AT+SEND=1,10,F,"  + String(fire);
  Serial.println(fireString);
  
 }
